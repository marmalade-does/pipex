
#ifndef LIBFT_H
# define LIBFT_H
# define BUFFER_SIZE 1024


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdarg.h>
#include <fcntl.h>



//
// stick your functions here //
//

#endif
